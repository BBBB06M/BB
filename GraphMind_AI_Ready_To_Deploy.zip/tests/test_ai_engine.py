from types import SimpleNamespace

import pytest

from ai_engine import generate_exercise


class FakeResponses:
    def __init__(self, output):
        self.output = output
        self.calls = 0

    def parse(self, **kwargs):
        self.calls += 1
        return SimpleNamespace(output_parsed=SimpleNamespace(**self.output))


class FakeClient:
    def __init__(self, output):
        self.responses = FakeResponses(output)


def sample(**changes):
    values = {
        "a": -3, "b": 8, "c": 5, "title": "Highest Point Challenge",
        "context": "A ball follows this quadratic height model. Find its vertex and opening.",
        "hint_1": "Look for the highest point of the curve.",
        "hint_2": "Use the vertex formula to find the time coordinate.",
        "learning_tip": "A negative leading coefficient means a downward-opening graph.",
    }
    values.update(changes)
    return values


def test_generate_uses_ai_response_and_validates():
    fake = FakeClient(sample())
    exercise = generate_exercise(fake, "gpt-5-mini", "Advanced")
    assert exercise.quadratic.vertex_y > 0
    assert exercise.level == "Advanced"
    assert fake.responses.calls == 1


def test_rejects_invalid_level_values_without_static_fallback():
    fake = FakeClient(sample(a=1, b=0))
    with pytest.raises(RuntimeError):
        generate_exercise(fake, "gpt-5-mini", "Advanced")
    assert fake.responses.calls == 3

@pytest.mark.parametrize(
    "level,coefs",
    [
        ("Foundation", (1, 0, -3)),
        ("Standard", (-2, 5, 2)),
    ],
)
def test_each_other_level_generates_valid_exercise(level, coefs):
    fake = FakeClient(sample(a=coefs[0], b=coefs[1], c=coefs[2]))
    exercise = generate_exercise(fake, "gpt-5-mini", level)
    assert (exercise.quadratic.a, exercise.quadratic.b, exercise.quadratic.c) == coefs
    assert exercise.level == level
