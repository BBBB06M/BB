from fractions import Fraction

import pytest

from math_engine import Quadratic, check_answer, fraction_label, terms, validate_level


def test_vertex_exact_fraction_standard():
    q = Quadratic(2, -3, -2)
    assert q.vertex_x == Fraction(3, 4)
    assert q.vertex_y == Fraction(-25, 8)
    assert q.opens == "Upward"


def test_advanced_peak_has_correct_height():
    q = Quadratic(-4, 12, 3)
    assert q.vertex_x == Fraction(3, 2)
    assert q.vertex_y == 12
    assert q.opens == "Downward"
    assert validate_level(q, "Advanced")


def test_basic_constraints_and_direction():
    assert validate_level(Quadratic(-1, 0, 4), "Foundation")
    assert not validate_level(Quadratic(1, 4, 4), "Foundation")
    assert not validate_level(Quadratic(1, 0, 4), "Standard")
    assert not validate_level(Quadratic(3, 0, 4), "Advanced")


def test_student_answer_checked_not_assumed():
    q = Quadratic(1, -4, 1)
    assert check_answer(q, 2, -3, "Upward").all_correct
    mark = check_answer(q, 2, -2.9, "Downward")
    assert mark.correct_count == 1


def test_presentation_and_input_rejection():
    assert fraction_label(Fraction(6, 4)) == "3/2"
    assert terms(-1, 0, 3) == "-x^2 + 3"
    assert terms(2, -3, -4, "t") == "2t^2 - 3t - 4"
    with pytest.raises(ValueError):
        Quadratic(0, 5, 3)
    with pytest.raises(TypeError):
        Quadratic(1.5, 3, 2)
