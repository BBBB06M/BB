"""Allow offline service tests when the optional external OpenAI SDK isn't installed.

The deployed application DOES require installing requirements.txt, including OpenAI.
"""
import sys
import types

try:
    from openai import OpenAI  # noqa: F401
except ImportError:
    placeholder = types.ModuleType("openai")
    placeholder.OpenAI = type("OpenAI", (), {})
    sys.modules["openai"] = placeholder
